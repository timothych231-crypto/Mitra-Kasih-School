const timetable = {
  Monday: [
    ["08:00–08:45","English","Room 9A","Ms. Taylor"],
    ["08:50–09:35","Mathematics","Room 9A","Mr. Adrian"],
    ["09:50–10:35","Science","Laboratory (RP)","Ms. Clara"],
    ["10:40–11:25","Social Studies","Room 9A","Mr. Daniel"]
  ],
  Tuesday: [
    ["08:00–08:45","Bahasa Indonesia","Room 9A","Ms. Nita"],
    ["08:50–09:35","Science","Laboratory (RP)","Ms. Clara"],
    ["09:50–10:35","English","Room 9A","Ms. Taylor"],
    ["10:40–11:25","Arts","Art Room (RP)","Mr. Kevin"]
  ],
  Wednesday: [
    ["08:00–08:45","Mathematics","Room 9A","Mr. Adrian"],
    ["08:50–09:35","Physical Education","Sports Hall (RP)","Coach Ryan"],
    ["09:50–10:35","Bahasa Indonesia","Room 9A","Ms. Nita"],
    ["10:40–11:25","Science","Laboratory (RP)","Ms. Clara"]
  ],
  Thursday: [
    ["08:00–08:45","Social Studies","Room 9A","Mr. Daniel"],
    ["08:50–09:35","English","Room 9A","Ms. Taylor"],
    ["09:50–10:35","Mathematics","Room 9A","Mr. Adrian"],
    ["10:40–11:25","Character Education (RP)","Room 9A","Ms. Grace"]
  ],
  Friday: [
    ["08:00–08:45","Class Meeting (RP)","Room 9A","Homeroom Teacher"],
    ["08:50–09:35","Arts","Art Room (RP)","Mr. Kevin"],
    ["09:50–10:35","Club Activities","Activity Hall (RP)","Club Leaders"],
    ["10:40–11:25","Community Time","School Yard (RP)","Staff (RP)"]
  ]
};

const scheduleBody = document.getElementById("scheduleBody");
const daySelect = document.getElementById("daySelect");
function renderSchedule(day) {
  scheduleBody.innerHTML = "";
  (timetable[day] || []).forEach(item => {
    const tr = document.createElement("tr");
    item.forEach(value => {
      const td = document.createElement("td");
      td.textContent = value;
      tr.appendChild(td);
    });
    scheduleBody.appendChild(tr);
  });
}
daySelect.addEventListener("change", () => renderSchedule(daySelect.value));
renderSchedule(daySelect.value);

document.getElementById("menuToggle").addEventListener("click", () => {
  document.getElementById("mainNav").classList.toggle("open");
});
document.querySelectorAll("#mainNav a").forEach(a => a.addEventListener("click", () => {
  document.getElementById("mainNav").classList.remove("open");
}));

document.getElementById("year").textContent = new Date().getFullYear();
const profileDialog = document.getElementById("profileDialog");
document.getElementById("editProfile").addEventListener("click", () => {
  document.getElementById("editName").value = document.getElementById("profileName").textContent === "Sample Student" ? "" : document.getElementById("profileName").textContent;
  document.getElementById("editGrade").value = document.getElementById("overviewClass").textContent;
  profileDialog.showModal();
});
document.getElementById("saveProfile").addEventListener("click", () => {
  const name = document.getElementById("editName").value.trim() || "Sample Student";
  const grade = document.getElementById("editGrade").value;
  document.getElementById("profileName").textContent = name;
  document.getElementById("profileAvatar").textContent = name.charAt(0).toUpperCase();
  document.getElementById("profileMeta").textContent = grade.replace("Grade ", "Grade ") + " • Student RP";
  document.getElementById("profileRoom").textContent = grade.replace("Grade ", "") + " (fictional)";
  document.getElementById("overviewClass").textContent = grade;
  profileDialog.close();
});

document.getElementById("loginForm").addEventListener("submit", event => {
  event.preventDefault();
  const name = document.getElementById("rpName").value.trim();
  const role = document.getElementById("rpRole").value;
  if (!name) return;
  document.getElementById("profileName").textContent = name;
  document.getElementById("profileAvatar").textContent = name.charAt(0).toUpperCase();
  document.getElementById("profileMeta").textContent = "Grade 9 • " + role + " RP";
  document.getElementById("profileStatus").textContent = "Demo session";
  document.getElementById("loginMessage").textContent = "Welcome, " + name + "! Demo profile updated.";
  document.getElementById("portal").scrollIntoView({behavior:"smooth"});
});

document.getElementById("addAnnouncement").addEventListener("click", () => {
  const title = prompt("Announcement title for your RP demo:");
  if (!title || !title.trim()) return;
  const body = prompt("Announcement details (fictional):") || "A new roleplay announcement.";
  const card = document.createElement("article");
  card.className = "announcement-card";
  const tag = document.createElement("span");
  tag.className = "tag";
  tag.textContent = "ROLEPLAY";
  const date = document.createElement("p");
  date.className = "date-label";
  date.textContent = new Date().toLocaleDateString("en-US", {year:"numeric", month:"long", day:"numeric"});
  const heading = document.createElement("h3");
  heading.textContent = title.trim();
  const details = document.createElement("p");
  details.textContent = body.trim();
  card.append(tag, date, heading, details);
  document.getElementById("announcementGrid").prepend(card);
});
