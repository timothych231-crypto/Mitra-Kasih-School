# Mitra Kasih School RP — Starter Website

This is a fan-made roleplay website inspired by a school portal. It is not the official school's website.

## Run it locally
1. Download and extract `mitra_kasih_school_rp.zip`.
2. Open the folder.
3. Double-click `index.html` to open it in a browser.

For easier editing, open the folder in Visual Studio Code and use the Live Server extension.

## Files
- `index.html` — page content and sections
- `style.css` — colors, layout, responsive design
- `script.js` — demo schedule, profile editor, demo login, and announcement interaction

## Important limitations
- The login is a front-end demo only. It does not securely authenticate anyone.
- Profile edits and announcements are not saved to a database and may disappear on refresh.
- All grades, attendance, names, teachers, classes, and events are fictional sample data.
- Do not enter real school passwords or private student data.
- The official website link is a separate external link: https://mrsyam.my.id/studentdash.html
- Before public launch, obtain any permissions needed for the real school's name or branding and clearly label the project as unofficial.
- For real accounts and shared data, add a secure backend, a database, server-side authentication, and access controls. Never store passwords in browser JavaScript.
